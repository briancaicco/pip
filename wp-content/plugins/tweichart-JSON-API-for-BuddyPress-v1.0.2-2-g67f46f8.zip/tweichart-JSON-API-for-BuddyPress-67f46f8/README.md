JSON-API-for-BuddyPress
=======================

JSON API for BuddyPress Plugin

==Introduction==

JSON API for BuddyPress is a plugin, that supports the JSON API Plugin with a new Controller to get information from BuddyPress.

For further information refer to the GitHub Project Page at http://tweichart.github.com/JSON-API-for-BuddyPress

==Release Notes==

===1.0.2===
* added possibility to get avatars and user meta data from profile_get_profile

===1.0.1===
* added support for de_DE
* added support for es_ES (all credits to the spanish translation to Andrew Kurtis from webhostinghub.com)
* changed folder structure

===1.0===
* code review
* added documentation

===0.9===
* now checking for permissions bevore retrieving data (security)
* need for authentication pushed to 2.0

===0.8===
* extended functionality for settings

===0.7===
* extended functionality for forums

===0.6===
* extended functionality for groups

===0.5===
* extended functionality for friends

===0.4===
* extended functionality for messages / notifications
* reworked the framework

===0.3===
* extended functionality for profile
* new parameter 'limit' for get_activity
* including error handler function

===0.2===
* extended functionality for activity

===0.1===
* initial commit 
